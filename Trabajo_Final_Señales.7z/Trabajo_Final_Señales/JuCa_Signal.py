# -*- coding: utf-8 -*-
"""
Created on Wed Apr 01 17:30:04 2019

@author: Juan
"""
import numpy as np
import LinearFIR ;
#import matplotlib.pyplot as plt;
from scipy import stats,signal

def Treat_signal(row_text,colums_text,Fsenal,Archive_name):
    Data = np.loadtxt(str(Archive_name)+'.txt',delimiter = ',',skiprows = row_text,dtype = bytes); #Carga una vez la señal   
    Data_Colums = Data.shape[1];  #toma las columnas totales del archivo  
    Colums_Use = np.arange(1,Data_Colums-colums_text); #Define el numero 
    Data = np.loadtxt(str(Archive_name)+'.txt',delimiter = ',',skiprows = row_text,usecols = Colums_Use);#Carga nuevamente el archivo con las modificaciones de filas y columnas=
    return (Data,len(Colums_Use));#regresa la señal y las columnas que se va a usar

def Filtered_Signal(Data,Colums,Fsenal):
    Initial_array = np.zeros((Colums,1,len(Data[:,0]))); #Creo una arreglo de 3 dimensiones de 0 (columnas,1,datos de cada canal)
    for i in np.arange(Colums):
        Initial_array[i] = LinearFIR.eegfiltnew(Data[:,i], Fsenal, 50 , 1 , 0, 0); #Aplica filtro pasa bandas de frecuencia baja 1 hz y frecuencia alta 50 hz y asigna cada valor al arreglo vacio creado anteriormente
    return(Initial_array); #Regresa el arreglo con los valores 
     
def All_Epoch(Chanel,Fm,Split_Time,Colums,Signal_Time): 
    try:    
        Init = Chanel[0][0][0:(Signal_Time*Fm)]; #toma el primer grupo de valores del canal uno 
        Duration_Epoch = ((len(Init)/Fm)/Split_Time); # determina el tamaño de cada epoca
        Splits = Chanel[0,0,0:(Signal_Time*Fm)]; # Realiza el corte para el primer canal 
        Splits = np.split(Splits,Duration_Epoch) ; #Crear el primer arreglo 
        for i in np.arange(1,Colums): # realiza el proceso anterior pero para los n canales 
            Next_Split = Chanel[i,0,0:(Signal_Time*Fm)];
            Next_Split = np.split(Next_Split,Duration_Epoch);
            Splits = np.concatenate ([Splits,Next_Split]);
        return(Splits,int(Duration_Epoch));
    except:
        return("Signal_Time or Split_Time",1)
def Delete_Bad_Epoch_1(All_Epocs,Duration_Epoch,Colums,Comparation):
    Vector = []; #crea un vector vacio
    Final_Signal = np.array(All_Epocs); 
    for i in np.arange(Duration_Epoch*Colums):
        y= All_Epocs[i];      
        if  Comparation < np.amax(y) or -Comparation > np.amin(y)  : # compara el valor maximo de la señal y minimo de la señal, compara con el valor ingresado por el usuario 
            Final_Signal[i]= Final_Signal[i]*0; # si es mayor al valor de comparacion o menor al valor negativo de comparacion elimina la epoca
            Vector.append(i);         
        else: 
            Final_Signal[i] = Final_Signal[i]*1;          # en otra caso deja la señal tal cual  
    Final  = Worker(Final_Signal,Duration_Epoch,Vector); # esta funcion elimina los canales restantes              
    return(Final);

def Delete_Bad_Epoch_2(All_Epocs,Duration_Epoch,Colums,Comparation,Signal_Time,Fm):
    Vector = [];
    Array = np.arange((Signal_Time*Fm)/Duration_Epoch)    
    Final_Signal = np.array(All_Epocs);
    for i in np.arange(Duration_Epoch*Colums):
        slope , intercept , r_value , p_value , s = stats.linregress(All_Epocs[i],Array);       
        if  Comparation < slope or -Comparation > slope : 
            Final_Signal[i]= Final_Signal[i]*0;
            Vector.append(i);
        else:
            Final_Signal[i]= Final_Signal[i]*1;
    Final =  Worker(Final_Signal,Duration_Epoch,Vector);    
    return(Final);
    
def Delete_Bad_Epoch_3(All_Epocs,Duration_Epoch,Colums,Comparation):
    Vector = [];
    Final_Signal = np.array(All_Epocs); 
    for i in np.arange(Duration_Epoch*Colums):
        y= All_Epocs[i];     
        if  Comparation < stats.kurtosis(y)> -Comparation:
            Final_Signal[i]= Final_Signal[i]*0;
            Vector.append(i);         
        else: 
            Final_Signal[i] = Final_Signal[i]*1;            
    Final =  Worker(Final_Signal,Duration_Epoch,Vector); 
    return(Final);
    
def Delete_Bad_Epoch_4(All_Epocs,Duration_Epoch,Colums,Comparation,Fm):   
    k= All_Epocs[0];
    Frequency,Final_Signal =signal.welch(k,Fm)    
    x = np.zeros((len(Frequency[:]),Duration_Epoch*Colums))
    y = np.zeros((len(Frequency[:]),Duration_Epoch*Colums))    
    for i in np.arange(1,Duration_Epoch*Colums):      
        k= All_Epocs[i]; 
        Frequency,Final_Signal =signal.welch(k,Fm)
        x[:,i]= Frequency;
        y[:,i]= Final_Signal;        
        if np.amax(y[:,i]) > Comparation : 
            y[:,i] = y[:,i]*0;
        else:
            y[:,i] = y[:,i]*1;                
    return(x,y);            
    
def Worker(Final_Signal,Duration_Epoch,Vector):      
    Constan_1 = 0;
    Constan_2 = -1*Duration_Epoch;
    Constan_3 = -2*Duration_Epoch;
    Constan_4 = -3*Duration_Epoch;
    Constan_5 = -4*Duration_Epoch;
    Constan_6 = -5*Duration_Epoch;
    Constan_7 = -6*Duration_Epoch;    
    for i in Vector:
        if i < Duration_Epoch:
            for n in np.arange(Colums) :
                try:
                    Final_Signal[i+Constan_1] = Final_Signal[i+Constan_1]*0 ;
                    Constan_1 = Constan_1  + Duration_Epoch ;
                except: 
                    Constan_1 = 0
        if Duration_Epoch < i < Duration_Epoch*2:
            for n in np.arange(Colums) :
                try:
                    Final_Signal[i+Constan_2] = Final_Signal[i+Constan_2]*0 ;       
                    if n == 0:
                        Constan_2 =  Constan_2 + 2*Duration_Epoch  ;                    
                    else:
                        Constan_2 =  Constan_2 + Duration_Epoch ;                      
                except: 
                    Constan_2 =  -Duration_Epoch;                    
        if Duration_Epoch*3 < i < Duration_Epoch*4:            
            for n in np.arange(Colums) :
                try:               
                    Final_Signal[i+Constan_3] = Final_Signal[i+Constan_3]*0 ;                    
                    if n == 1:
                        Constan_3 = Constan_3 + 3*Duration_Epoch;
                    else:
                        Constan_3 =  Constan_3 + Duration_Epoch ;                   
                except: 
                    Constan_3 = -2*Duration_Epoch;                                         
        if Duration_Epoch*4 < i < Duration_Epoch*5:            
            for n in np.arange(Colums) :
                try:
                    Final_Signal[i+Constan_4] = Final_Signal[i+Constan_4]*0 ;                    
                    if n == 2:
                        Constan_4 =  Constan_4 + 4*Duration_Epoch;
                    else:
                        Constan_4 = Constan_4 + Duration_Epoch ;                    
                except: 
                    Constan_4 = -3*Duration_Epoch;                    
        if Duration_Epoch*5 < i < Duration_Epoch*6:            
            for n in np.arange(Colums) :
                try:
                    Final_Signal[i+Constan_5] = Final_Signal[i+Constan_5]*0 ;                    
                    if n == 3:
                        Constan_5 =  Constan_5 + 5*Duration_Epoch;
                    else:
                        Constan_5 =  Constan_5 + Duration_Epoch;                    
                except: 
                    Constan_5 = -4*Duration_Epoch;                   
        if Duration_Epoch*6 < i < Duration_Epoch*7:           
            for n in np.arange(Colums) :
                try:
                    Final_Signal[i+Constan_6] = Final_Signal[i+Constan_6]*0 ;                    
                    if n == 4:
                        Constan_6 =  Constan_6 + 6*Duration_Epoch;
                    else:
                        Constan_6 =  Constan_6 + Duration_Epoch;                   
                except: 
                    Constan_6 = -6*Duration_Epoch;                    
        if Duration_Epoch*7 < i < Duration_Epoch*8:            
            for n in np.arange(Colums) :
                try:
                    Final_Signal[i+Constan_7] = Final_Signal[i+Constan_7]*0 ;                    
                    if n == 5:
                        Constan_7 =  Constan_7 + 7*Duration_Epoch;
                    else:
                        Constan_7 = Constan_7 + Duration_Epoch;                   
                except: 
                    Constan_7 = -6*Duration_Epoch;                        
    return(Final_Signal)


file = "P1_RAWEEG_2018-11-15_Electrobisturí1_3min"     #nombre del Archivo
   
Data, Colums = Treat_signal(6,4,250,file);                                                     # Funcion  #llama a la funcion para abrir el archivo necesita (numero de filas que no se desena del txt, columnas finales que se deseen eliminar del txt,Frecuencia de la señal,nombre del archivo ),Colums es la cantidad de canales a implementar maximo 8 

Data_Filtered = Filtered_Signal(Data,Colums,250);                                              #Filteresd_ Signal regresa un arreglo de 3 dimensiones con cada uno de los canales filtrados, la funcion necesita de (los datos, las columnas y la frecuencia de la señal)

All_Epocs, Duration_Epoch = All_Epoch(Data_Filtered,250,3,Colums,180);                         #Funcion para segmentar cada uno de los canales  necesita de (los datos filtrados, frecuencia de la señal,cada cuantas segundos se hara el corte,la cantidad de columnas )

Final_Signal_1 = Delete_Bad_Epoch_1(All_Epocs,Duration_Epoch,Colums,100);                      #primer metodo para eliminar epocas atipicas por medio de comparacion de maximos y minimos de la señal 

Final_Signal_2= Delete_Bad_Epoch_2(All_Epocs,Duration_Epoch,Colums,0.3,180,250);               #segundo metodo para eliminar epocas atipicas por minimos cuadraso(datos,duracuib de la epoca,columnas,pendeinte de comparacion,tiempo de la señal,frecuencia de la señal) 

Final_Signal_3 = Delete_Bad_Epoch_3(All_Epocs,Duration_Epoch,Colums,2);                        # metodo para eliminar por kurtosis(",",",Valor de comparacion)

Final_Frequency , Final_Signal_4  = Delete_Bad_Epoch_4(All_Epocs,Duration_Epoch,Colums,40,250) #Metodo para eliminar por Comparacion con la potencia(",",",valor de comparacion,frecuencia de la señal )



# para los final_signal de 1 a 3 regresa un arreglo de n filas y m columnas donde cada Duration_Epoch en las filas es cada canal 

















